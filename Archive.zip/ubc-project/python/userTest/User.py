import random


class User:
    def __init__(self, nm, user_id, pw):
        self.Username = nm
        self.ID = user_id
        self.Password = pw


myUsers = []

x = 1
while x < 30:
    myUsers.append(User(x, 300000 + x, random.randint(1000, 9000)))
    x += 1

for obj in myUsers:
    print("Username: %d" % obj.Username)
    print("ID: %d" % obj.ID)
    print("Password: %d" % obj.Password + '\n')
