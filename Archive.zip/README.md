# HTML/CSS/JavaScript testing or practicing

Relevant files are in ubc-project>web