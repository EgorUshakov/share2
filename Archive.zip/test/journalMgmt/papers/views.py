from django.utils import timezone
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required 
from django.contrib.auth import authenticate, login 
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import logout
from .forms import SubmitButton


@login_required
def home_page_view(request): # Name changed 
	return render(request, 'papers/home.html', {})

## New #######################
def register_page_view(request): # Used for registering a user 
	form = UserCreationForm(request.POST or None) 
	if request.method == "POST":
		if form.is_valid():
			form.save()
			username = form.cleaned_data.get('username')
			password = form.cleaned_data.get('password1')
			user = authenticate(username = username, password = password)
			login(request, user)
			return redirect('/')
		else:
			return render(request, 'papers/signup.html', {'form':form})
	else:
		form = UserCreationForm()
		return render(request, 'papers/signup.html', {'form':form})	
## New #########################
def login_in_page(request):
	if request.user.is_authenticated:
		return render(request, 'papers/login.html')
	if request.method=='POST':
		username = request.POST['username'];
		password = request.POST['password'];
		user = authenticate(request, username=username, password=password)
		if user is not None:
			login(request, user)
			return redirect('/')
		else:
			form = AuthenticationForm(request.POST)
			return render(request, 'papers/login.html', {'form':form})
	else:
		form = AuthenticationForm()
		return render(request, 'papers/login.html', {'form':form})
## New ##########################
def logout_page_view(request):
	logout(request)
	return redirect('/')
## New ##########################

def publications(request):
    # GET request to download published journals

    # if request.method == 'GET':

    # else:

    return render(request, 'papers/publications.html', {})


def staff(request):
    return render(request, 'papers/staff.html', {})


def account(request):
    return render(request, 'papers/account.html', {})


def researcher_account(request):
    return render(request, 'papers/researcher_account.html', {})


def reviewer_account(request):
    return render(request, 'papers/reviewer_account.html', {})


def editor_account(request):
    return render(request, 'papers/editor_account.html', {})


# view dealing with 'submit a paper' page
def submit(request):

    # creating a submit button

    # save user uploaded form when post request is made with valid input

    if request.method == 'POST':
        form = SubmitButton(request.POST, request.FILES)

        # set the paper_author field to be the currently logged-in user
        # set the upload_date field to be the time of uplad
        if form.is_valid():
            paper = form.save(commit=False)
            paper.paper_author = request.user
            paper.upload_date = timezone.now()
            paper.save()

    # if the page receives a GET request, submit button should still appear
    else:
        form = SubmitButton()

    # return the html file used to display the page, with the form to be used
    return render(request, 'papers/submit.html', {'form': form})


def submissions(request):
    # GET request for papers user has submitted

    # if request.method == 'GET':

    # else:

        return render(request, 'papers/account.html', {})
