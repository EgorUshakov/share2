
from django.contrib import admin
from .models import Papers 

admin.site.register(Papers)

