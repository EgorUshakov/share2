from django.urls import path

from papers.views import *

urlpatterns = [
	path('account/login/', login_in_page), # New 
    path('account/register/',  register_page_view), # New
    path('account/logout', logout_page_view), # New
   	path('', home_page_view), # Updated: 
    path('publications/', publications, name='publications'),
    path('staff/', staff, name='staff'),
    path('account/', account, name='account'),
    path('researcher_account/', researcher_account, name='researcher_account'),
    path('reviewer_account/', reviewer_account, name='reviewer_account'),
    path('editor_account/', editor_account, name='editor_account'),
    path('account/submit/', submit, name='submit'),
    path('account/submissions/', submissions, name='submissions'),

]

''' if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT) '''
