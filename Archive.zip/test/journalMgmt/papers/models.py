from django.contrib.auth.models import User
from django.db import models
from django.conf import settings 


class Papers(models.Model):
    paper_author = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)

    paper_title = models.CharField(max_length=255)

    #uploads file to ../papers folder
    paper_file = models.FileField(upload_to='papers/')

    upload_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.paper_title 
