from django import forms

from .models import Papers


# Form to format the 'upload/submit paper' button
class SubmitButton(forms.ModelForm):
    # form takes a paper object and displays a place for the title and file
    class Meta:
        model = Papers
        fields = ('paper_title', 'paper_file',)

